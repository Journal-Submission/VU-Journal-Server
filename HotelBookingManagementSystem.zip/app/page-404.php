<?php 
echo "page not found (404)";
?>